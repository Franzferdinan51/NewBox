import React, { useEffect, useState } from "react";
import axios from "axios";
import MovieCard from "./MovieCard";
import { Container, Row } from "reactstrap";
export default function MovieList() {
  // NOTE: The value given to useState() must be of the same type as your vale is expected to be
  const [films, setFilms] = useState([]);

  useEffect(() => {
    axios
      .get(`https://ghibliapi.herokuapp.com/films/`)
      .then(response => {
        const filmInfo = response.data;
        console.log("studio ghibli films", filmInfo);
        setFilms(filmInfo);
      })
      .catch(error => {
        console.log("The data was not returned", error);
      });
  }, []);

  return (
    <Container>
      <Row>
        {films.map(film => {
          return (
            <MovieCard
              key={film.id}
              title={film.title}
              description={film.description}
              director={film.director}
              release_date={film.release_date}
            />
          );
        })}
      </Row>
    </Container>
  );
}
