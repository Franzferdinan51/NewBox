import React from "react";
import { Card, CardBody, CardTitle, CardText, CardImg, Col } from "reactstrap";

const MovieCard = props => {
  return (
    <Col key={props.id}>
      <Card>
        <div
          width="100%"
          src="https://source.unsplash.com/random"
          alt="Card image cap"
        />
        <div>
          <div>Film title: {props.title}</div>
          <div>{props.description}</div>
          <div>Director: {props.director}</div>
          <div>
            <div className="text-muted">Release date: {props.release_date}</div>
          </div>
        </div>
      </Card>
    </Col>
  );
};
export default MovieCard;
